<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Power BI Debug Information</h2>

    <div class="card mb-4">
        <div class="card-header">
            <h5>Authentication Status</h5>
        </div>
        <div class="card-body">
            <p><strong>Authenticated:</strong> <?php echo e($isAuthenticated ? 'Yes' : 'No'); ?></p>
        </div>
    </div>

    <div class="card">
        <div class="card-header">
            <h5>User Workspaces</h5>
        </div>
        <div class="card-body">
            <?php if(isset($workspaces['error'])): ?>
                <div class="alert alert-danger"><?php echo e($workspaces['error']); ?></div>
            <?php else: ?>
                <table class="table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Type</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $workspaces['value'] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $workspace): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><code><?php echo e($workspace['id']); ?></code></td>
                            <td><?php echo e($workspace['name']); ?></td>
                            <td><?php echo e($workspace['type']); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </div>

    <div class="mt-3">
        <a href="<?php echo e(route('reports.show')); ?>" class="btn btn-primary">Try Reports Again</a>
        <a href="<?php echo e(route('powerbi.logout')); ?>" class="btn btn-secondary">Logout</a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Development\Karavel\ETHBIAuthenticator\resources\views\reports\debug.blade.php ENDPATH**/ ?>