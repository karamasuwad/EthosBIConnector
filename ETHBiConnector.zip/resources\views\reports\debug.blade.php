@extends('layouts.app')

@section('content')
<div class="container">
    <h2>Power BI Debug Information</h2>

    <div class="card mb-4">
        <div class="card-header">
            <h5>Authentication Status</h5>
        </div>
        <div class="card-body">
            <p><strong>Authenticated:</strong> {{ $isAuthenticated ? 'Yes' : 'No' }}</p>
        </div>
    </div>

    <div class="card">
        <div class="card-header">
            <h5>User Workspaces</h5>
        </div>
        <div class="card-body">
            @if(isset($workspaces['error']))
                <div class="alert alert-danger">{{ $workspaces['error'] }}</div>
            @else
                <table class="table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Type</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($workspaces['value'] ?? [] as $workspace)
                        <tr>
                            <td><code>{{ $workspace['id'] }}</code></td>
                            <td>{{ $workspace['name'] }}</td>
                            <td>{{ $workspace['type'] }}</td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            @endif
        </div>
    </div>

    <div class="mt-3">
        <a href="{{ route('reports.show') }}" class="btn btn-primary">Try Reports Again</a>
        <a href="{{ route('powerbi.logout') }}" class="btn btn-secondary">Logout</a>
    </div>
</div>
@endsection
