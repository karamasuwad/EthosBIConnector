<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\BiLinkController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\ConnectedUserController;
use App\Http\Controllers\PowerBIController;

Route::get('/login', [LoginController::class, 'index'])->name('login');
Route::post('/login', [LoginController::class, 'login']);
Route::post('/logout', [LoginController::class, 'logout'])->name('logout');

// routes/web.php

Route::get('/powerbi/test-auth', [PowerBIController::class, 'testAuth'])->name('powerbi.test-auth');


Route::get('/test-powerbi', function() {
    try {
        $user = 'admin@zenkokenya.com';//auth()->user();
        return response()->json([
            'user' => $user->email,
            'has_powerbi_token' => !empty(session('powerbi_access_token')),
            'powerbi_user_email' => session('powerbi_user')['email'] ?? 'none',
            'workspace_access' => true,
            'session_keys' => array_keys(session()->all())
        ]);
    } catch (\Exception $e) {
        return response()->json(['error' => $e->getMessage()], 500);
    }
});

Route::middleware(['auth'])->group(function () {
    Route::get('/', [LoginController::class, 'dashboard'])->name('home');
    Route::get('/dashboard', [LoginController::class, 'dashboard'])->name('dashboard');


    // BI Links CRUD
    Route::resource('bi-links', BiLinkController::class);

    // Users
    Route::resource('users', UserController::class);
    Route::post('/users/{user}/activate', [UserController::class, 'activate'])->name('users.activate');

    // Connected Users
    Route::get('/connected-users', [ConnectedUserController::class, 'index'])->name('connected-users.index');
    Route::get('/connected-users/count', [ConnectedUserController::class, 'getActiveCount'])->name('connected-users.count');

    // Power BI Reports
    // Power BI Authentication Routes
    Route::get('/powerbi/login', [PowerBIController::class, 'redirectToPowerBI'])->name('powerbi.login');
    Route::get('/powerbi/callback', [PowerBIController::class, 'handleCallback'])->name('powerbi.callback');
    Route::get('/powerbi/logout', [PowerBIController::class, 'logout'])->name('powerbi.logout');
    Route::get('/powerbi/debug', [PowerBIController::class, 'debug'])->name('powerbi.debug');
    Route::get('/powerbi/connect', [PowerBIController::class, 'redirectToPowerBI'])->name('powerbi.connect');

    Route::get('/powerbi/test-auth', [PowerBIController::class, 'testAuth'])->name('powerbi.test-auth');
    Route::get('/powerbi/debug', [PowerBIController::class, 'debug'])->name('powerbi.debug');
    Route::get('/powerbi/logout', [PowerBIController::class, 'logout'])->name('powerbi.logout');


    // Reports Routes// Reports Routes
    Route::get('/reports', [PowerBIController::class, 'showReport'])->name('reports.show');
    Route::get('/reports/simple', [PowerBIController::class, 'simpleEmbed'])->name('reports.simple');
    Route::get('/reports-error', [PowerBIController::class, 'error'])->name('reports.error');


    // Redirect root to reports
    Route::redirect('/', '/reports');



    // Debug routes for Power BI
    Route::get('/powerbi/check-env', function() {
        $envVars = [
            'POWERBI_CLIENT_ID' => env('POWERBI_CLIENT_ID') ? '***' . substr(env('POWERBI_CLIENT_ID'), -8) : 'MISSING',
            'POWERBI_CLIENT_SECRET' => env('POWERBI_CLIENT_SECRET') ? '***' . substr(env('POWERBI_CLIENT_SECRET'), -8) : 'MISSING',
            'POWERBI_REDIRECT_URI' => env('POWERBI_REDIRECT_URI') ?: 'MISSING',
            'POWERBI_WORKSPACE_ID' => env('POWERBI_WORKSPACE_ID') ?: 'MISSING',
            'POWERBI_TENANT_ID' => env('POWERBI_TENANT_ID') ?: 'MISSING',
            'APP_URL' => env('APP_URL') ?: 'MISSING'
        ];

        return response()->json([
            'environment_variables' => $envVars,
            'redirect_uri_validation' => [
                'matches_app_url' => str_contains(env('POWERBI_REDIRECT_URI', ''), env('APP_URL', '')),
                'expected_callback' => env('APP_URL') ? env('APP_URL') . '/powerbi/callback' : 'N/A'
            ]
        ]);
    })->name('powerbi.check-env');

    Route::get('/powerbi/debug-callback', function(Illuminate\Http\Request $request) {
        \Log::info('DEBUG CALLBACK - Raw request data', $request->all());

        return response()->json([
            'received_parameters' => $request->all(),
            'has_code' => $request->has('code'),
            'has_error' => $request->has('error'),
            'code_length' => $request->has('code') ? strlen($request->get('code')) : 0,
            'error_info' => $request->only(['error', 'error_description']),
            'state' => $request->get('state'),
            'full_url' => $request->fullUrl()
        ]);
    })->name('powerbi.debug-callback');

    // List all Power BI routes
    Route::get('/powerbi/routes', function() {
        $powerbiRoutes = collect(Route::getRoutes())->filter(function ($route) {
            return str_contains($route->uri(), 'powerbi') || str_contains($route->uri(), 'report');
        })->map(function ($route) {
            return [
                'method' => implode('|', $route->methods()),
                'uri' => $route->uri(),
                'name' => $route->getName(),
                'action' => $route->getActionName(),
            ];
        })->values();

        return response()->json($powerbiRoutes);
    })->name('powerbi.routes');

    // routes/web.php - Add this temporary route
    Route::get('/powerbi/callback-test', function(Illuminate\Http\Request $request) {
        \Log::info('=== CALLBACK TEST ===');
        \Log::info('Full URL: ' . $request->fullUrl());
        \Log::info('Query Parameters:', $request->query());
        \Log::info('Has code: ' . ($request->has('code') ? 'YES' : 'NO'));
        \Log::info('Has error: ' . ($request->has('error') ? 'YES' : 'NO'));

        if ($request->has('error')) {
            \Log::error('Callback Error:', [
                'error' => $request->get('error'),
                'description' => $request->get('error_description')
            ]);
        }

        return response()->json([
            'status' => 'callback_received',
            'has_code' => $request->has('code'),
            'has_error' => $request->has('error'),
            'error_info' => $request->only(['error', 'error_description']),
            'code_length' => $request->has('code') ? strlen($request->get('code')) : 0,
            'all_parameters' => $request->query()
        ]);
    });


    // routes/web.php - Add this route
    Route::get('/powerbi/route-check', function() {
        $routes = [
            '/powerbi/login' => route('powerbi.login'),
            '/powerbi/callback' => route('powerbi.callback'),
            '/powerbi/debug' => route('powerbi.debug'),
            '/reports' => route('reports.show'),
        ];

        // Test if routes are accessible
        $accessible = [];
        foreach ($routes as $name => $url) {
            try {
                $accessible[$name] = [
                    'url' => $url,
                    'exists' => true,
                    'accessible' => true
                ];
            } catch (Exception $e) {
                $accessible[$name] = [
                    'url' => $name,
                    'exists' => false,
                    'error' => $e->getMessage()
                ];
            }
        }

        return response()->json([
            'routes' => $accessible,
            'app_url' => config('app.url'),
            'current_url' => url()->current()
        ]);
    });


    // routes/web.php
    Route::get('/powerbi/test-user', function() {
        $userInfo = session('powerbi_user');
        $accessToken = session('powerbi_access_token');

        return response()->json([
            'session_user' => $userInfo,
            'laravel_user' => auth()->check() ? [
                'email' => auth()->user()->email,
                'name' => auth()->user()->name
            ] : 'not_authenticated',
            'has_access_token' => !empty($accessToken),
            'token_length' => strlen($accessToken ?? '')
        ]);
    });

});


// routes/web.php - Fix the callback debug route
Route::get('/powerbi/callback-debug', function(Illuminate\Http\Request $request) {
    \Log::info('CALLBACK DEBUG - All request data:', $request->all());
    \Log::info('CALLBACK DEBUG - Query parameters:', $request->query());
    \Log::info('CALLBACK DEBUG - Headers:', ['headers' => $request->header()]);

    return response()->json([
        'query_params' => $request->query(),
        'has_code' => $request->has('code'),
        'has_error' => $request->has('error'),
        'code_length' => strlen($request->get('code') ?? ''),
        'error_info' => $request->only(['error', 'error_description']),
        'state' => $request->get('state'),
        'full_url' => $request->fullUrl()
    ]);
});
