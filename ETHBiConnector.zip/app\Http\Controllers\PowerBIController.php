<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Services\PowerBIService;

class PowerBIController extends Controller
{
    private $powerbi;

    public function __construct(PowerBIService $powerbi)
    {
        $this->powerbi = $powerbi;
    }

    public function redirectToPowerBI()
    {
        return $this->powerbi->redirectToPowerBI();
    }

    public function handleCallback(Request $request)
    {
        return $this->powerbi->handleCallback($request);
    }

    public function showReport()
    {
        // Check if user is authenticated
        if (!$this->powerbi->isAuthenticated()) {
            return redirect()->route('powerbi.login')->with('error', 'Please authenticate with Power BI first.');
        }

        try {
            // Get embed configuration
            $embedConfig = $this->powerbi->getEmbedConfig();

            if (isset($embedConfig['error'])) {
                \Log::error('Power BI embed error', $embedConfig);
                return redirect()->route('reports.error')->with('error', 'Failed to load Power BI report: ' . $embedConfig['error']);
            }

            return view('reports.index', $embedConfig);

        } catch (\Exception $e) {
            \Log::error('Show Report Error', ['message' => $e->getMessage()]);
            return redirect()->route('reports.error')->with('error', 'Error loading report: ' . $e->getMessage());
        }
    }

    /**
     * Simple embed without complex authentication
     */
    public function simpleEmbed()
    {
        $embedConfig = $this->powerbi->getSimpleEmbedConfig();
        return view('reports.simple', $embedConfig);
    }

    public function error()
    {
        return view('reports.error');
    }

    public function logout()
    {
        $this->powerbi->logout();
        return redirect('/')->with('success', 'Logged out from Power BI');
    }




     /**
     * Debug endpoint to check authentication status - FIXED VERSION
     */
    public function debug()
    {
        try {
            // Safely get user information
            $user = 'admin@zenkokenya.com';//auth()->user();
            $userEmail = 'admin@zenkokenya.com';// $user ? $user->email : 'Not authenticated';

            $isPowerBIAuthenticated = $this->powerbi->isAuthenticated();

            // Safely get session data
            $sessionData = [
                'powerbi_access_token' => session('powerbi_access_token') ? '***' . substr(session('powerbi_access_token'), -10) : null,
                'powerbi_user' => session('powerbi_user'),
                'powerbi_token_expires' => session('powerbi_token_expires'),
                'laravel_user_id' => $user ? $user->id : null,
            ];

            return response()->json([
                'laravel_authentication' => [
                    'authenticated' => !is_null($user),
                    'user_email' => $userEmail,
                    'user_type' => gettype($user)
                ],
                'powerbi_authentication' => [
                    'authenticated' => $isPowerBIAuthenticated,
                    'has_token' => !empty(session('powerbi_access_token')),
                    'token_length' => strlen(session('powerbi_access_token') ?? ''),
                    'user_email' => session('powerbi_user')['email'] ?? 'none'
                ],
                'environment_check' => [
                    'client_id_set' => !empty(env('POWERBI_CLIENT_ID')),
                    'client_secret_set' => !empty(env('POWERBI_CLIENT_SECRET')),
                    'workspace_id_set' => !empty(env('POWERBI_WORKSPACE_ID')),
                    'redirect_uri' => env('POWERBI_REDIRECT_URI'),
                ],
                'session_keys' => array_keys(session()->all())
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'error' => $e->getMessage(),
                'user_type' => gettype(auth()->user()),
                'user_value' => auth()->user()
            ], 500);
        }
    }


    public function testAuth()
    {
        try {
            \Log::info('Power BI Auth Test Started', ['user' => 'admin@zenkokenya.com' ]);

            // Clear any existing session
            $this->powerbi->logout();

            // Start fresh authentication
            return $this->powerbi->redirectToPowerBI();

        } catch (\Exception $e) {
            \Log::error('Power BI Auth Test Failed', ['error' => $e->getMessage()]);
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }

}
