<!DOCTYPE html>
<html>
<head>
    <title>Power BI Report - Simple Embed</title>
    <style>
        body, html {
            margin: 0;
            padding: 0;
            height: 100%;
            font-family: Arial, sans-serif;
        }
        iframe {
            width: 100%;
            height: 100vh;
            border: none;
        }
        .header {
            padding: 10px 20px;
            background: #f8f9fa;
            border-bottom: 1px solid #dee2e6;
        }
        .btn {
            padding: 8px 16px;
            background-color: #007bff;
            color: white;
            text-decoration: none;
            border-radius: 4px;
            margin-right: 10px;
        }
    </style>
</head>
<body>
    <div class="header">
        <a href="{{ route('reports.show') }}" class="btn">Authenticated Embed</a>
        <a href="{{ route('powerbi.login') }}" class="btn" style="background-color: #28a745;">Login</a>
    </div>
    <iframe
        src="{{ $embedUrl }}&autoAuth=true"
        frameborder="0"
        allowFullScreen="true">
    </iframe>
</body>
</html>
