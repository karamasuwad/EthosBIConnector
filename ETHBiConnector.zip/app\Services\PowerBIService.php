<?php

namespace App\Services;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Log;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class PowerBIService
{
    private $tenantId;
    private $clientId;
    private $clientSecret;
    private $workspaceId;

    public function __construct()
    {
        $this->tenantId = env('POWERBI_TENANT_ID', '2d64f580-311b-4579-a778-e50a164610b2');
        $this->clientId = env('POWERBI_CLIENT_ID');
        $this->clientSecret = env('POWERBI_CLIENT_SECRET');
        $this->workspaceId = env('POWERBI_WORKSPACE_ID', '1f2c58d1-3558-480d-9c31-ce7f78a13f68');
    }

    public function redirectToPowerBI()
    {
        \Log::info('Initiating Power BI authentication redirect', [
            'laravel_user' => 'admin@zenkokenya.com', //auth()->user()->email,
            'client_id' => $this->clientId ? 'set' : 'missing',
            'redirect_uri' => env('POWERBI_REDIRECT_URI')
        ]);

        $query = http_build_query([
            'client_id' => $this->clientId,
            'response_type' => 'code',
            'redirect_uri' => env('POWERBI_REDIRECT_URI'),
            'response_mode' => 'query',
            'scope' => 'https://analysis.windows.net/powerbi/api/.default offline_access',
            'state' => csrf_token(),
            'prompt' => 'select_account',
        ]);

        $authUrl = "https://login.microsoftonline.com/" . $this->tenantId . "/oauth2/v2.0/authorize?" . $query;

        \Log::info('Power BI Auth URL generated', ['url' => $authUrl]);

        return redirect($authUrl);
    }

    public function handleCallback(Request $request)
    {
        \Log::info('PowerBI Callback Received', $request->all());

        if ($request->has('error')) {
            \Log::error('PowerBI Auth Error', [
                'error' => $request->get('error'),
                'description' => $request->get('error_description')
            ]);
            return redirect()->route('reports.error')->with('error', 'Authentication failed: ' . $request->get('error_description'));
        }

        $code = $request->get('code');

        if (!$code) {
            \Log::error('No authorization code received');
            return redirect()->route('reports.error')->with('error', 'No authorization code received');
        }

        try {
            $response = Http::asForm()->post(
                "https://login.microsoftonline.com/" . $this->tenantId . "/oauth2/v2.0/token",
                [
                    'grant_type' => 'authorization_code',
                    'client_id' => $this->clientId,
                    'client_secret' => $this->clientSecret,
                    'redirect_uri' => env('POWERBI_REDIRECT_URI'),
                    'code' => $code,
                    'scope' => 'https://analysis.windows.net/powerbi/api/.default',
                ]
            );

            $data = $response->json();

            if (!isset($data['access_token'])) {
                \Log::error('Power BI Token Exchange Failed', $data);
                return redirect()->route('reports.error')->with('error', 'Failed to get access token: ' . ($data['error_description'] ?? 'Unknown error'));
            }

            // Get user info for RLS
            $userInfo = $this->getUserInfo($data['access_token']);

            // Store in session
            // Session::put([
            //     'powerbi_access_token' => $data['access_token'],
            //     'powerbi_refresh_token' => $data['refresh_token'] ?? null,
            //     'powerbi_token_expires' => now()->addSeconds($data['expires_in'] ?? 3600),
            //     'powerbi_user' => $userInfo,
            // ]);

            // \Log::info('PowerBI Authentication Successful', ['user' => $userInfo]);
            Session::put([
                'powerbi_access_token' => $data['access_token'],
                'powerbi_refresh_token' => $data['refresh_token'] ?? null,
                'powerbi_token_expires' => now()->addSeconds($data['expires_in'] ?? 3600),
                'powerbi_user' => [
                    'email' => 'admin@zenkekenya.com', // HARDCODED
                    'name' => 'Admin Zenko'
                ],
            ]);

            \Log::info('PowerBI Authentication Successful with HARDCODED user', [
                'user' => 'admin@zenkekenya.com'
            ]);

            return redirect()->route('reports.show')->with('success', 'Connected to Power BI successfully!');

        } catch (\Exception $e) {
            \Log::error('PowerBI Callback Exception', [
                'message' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            return redirect()->route('reports.error')->with('error', 'Authentication failed: ' . $e->getMessage());
        }
    }

    /**
     * Get user information for RLS - FIXED VERSION
     */
    private function getUserInfo($accessToken)
    {
        try {
            \Log::info('Attempting to get user info from Microsoft Graph');

            $response = Http::withToken($accessToken)
                ->timeout(10)
                ->get('https://graph.microsoft.com/v1.0/me');

            \Log::info('Graph API response status', ['status' => $response->status()]);

            if ($response->successful()) {
                $userData = $response->json();
                \Log::info('User data received from Graph API', [
                    'mail' => $userData['mail'] ?? 'not_set',
                    'userPrincipalName' => $userData['userPrincipalName'] ?? 'not_set',
                    'displayName' => $userData['displayName'] ?? 'not_set'
                ]);

                // Priority: mail -> userPrincipalName -> fallback
                $email = $userData['mail'] ?? $userData['userPrincipalName'] ?? null;

                if (!$email) {
                    \Log::warning('No email found in user data');
                    return ['email' => 'unknown@example.com', 'name' => 'Unknown User'];
                }

                return [
                    'id' => $userData['id'] ?? null,
                    'email' => $email,
                    'name' => $userData['displayName'] ?? 'Unknown User',
                ];
            } else {
                \Log::error('Graph API request failed', [
                    'status' => $response->status(),
                    'body' => $response->body()
                ]);
            }
        } catch (\Exception $e) {
            \Log::error('Failed to get user info from Graph API', [
                'message' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
        }

        // Fallback: Try to get email from Laravel auth user
        if (auth()->check()) {
            $laravelUser = auth()->user();
            \Log::info('Using Laravel auth user as fallback', ['email' => $laravelUser->email]);
            return [
                'email' => $laravelUser->email,
                'name' => $laravelUser->name ?? 'Unknown User',
            ];
        }

        \Log::warning('No user info available, using fallback');
        return ['email' => 'unknown@example.com', 'name' => 'Unknown User'];
    }

    /**
     * Get embed configuration with RLS support
     */
    public function getEmbedConfig()
    {
        $reportId = '309fea67-becc-4898-866e-72a7d70e4f1a';
        $groupId = '1f2c58d1-3558-480d-9c31-ce7f78a13f68';
        $tenantId = '2d64f580-311b-4579-a778-e50a164610b2';

        try {
            // Check authentication
            if (!Session::has('powerbi_access_token')) {
                throw new \Exception('User not authenticated. Please login first.');
            }

            $accessToken = Session::get('powerbi_access_token');
            $userInfo = Session::get('powerbi_user', []);
            $userEmail = $userInfo['email'] ?? 'unknown@example.com';

            \Log::info('Generating embed configuration', [
                'user_email' => $userEmail,
                'reportId' => $reportId
            ]);

            // Get report details - this returns the OFFICIAL embed URL
            $reportResponse = Http::withToken($accessToken)
                ->get("https://api.powerbi.com/v1.0/myorg/groups/{$groupId}/reports/{$reportId}");

            if ($reportResponse->failed()) {
                \Log::error('Failed to fetch report details', [
                    'error' => $reportResponse->body(),
                    'status' => $reportResponse->status()
                ]);
                throw new \Exception('Cannot access report: ' . ($reportResponse->json()['error']['message'] ?? 'Unknown error'));
            }

            $report = $reportResponse->json();
            $datasetId = $report['datasetId'] ?? null;
            $embedUrl = $report['embedUrl'] ?? null;

            if (!$datasetId || !$embedUrl) {
                throw new \Exception('Report configuration error: missing dataset or embed URL.');
            }

            \Log::info('Retrieved official embed URL from API', [
                'datasetId' => $datasetId,
                'embedUrl' => $embedUrl,
                'reportName' => $report['name'] ?? 'Unknown'
            ]);

            // Generate embed token using the OFFICIAL embed URL
            $tokenPayload = [
                'accessLevel' => 'View',
                'allowSaveAs' => false,
                'datasets' => [
                    ['id' => $datasetId]
                ],
                'reports' => [
                    ['id' => $reportId]
                ]
            ];

            $tokenResponse = Http::withToken($accessToken)
                ->timeout(30)
                ->post("https://api.powerbi.com/v1.0/myorg/groups/{$groupId}/reports/{$reportId}/GenerateToken",
                    $tokenPayload
                );

            if ($tokenResponse->failed()) {
                \Log::error('Embed token generation failed', [
                    'error' => $tokenResponse->json(),
                    'status' => $tokenResponse->status()
                ]);
                throw new \Exception('Failed to generate embed token: ' .
                    ($tokenResponse->json()['error']['message'] ?? 'Unknown error'));
            }

            $tokenData = $tokenResponse->json();

            \Log::info('Embed configuration generated successfully');

            return [
                'embedToken' => $tokenData['token'],
                'embedUrl' => $embedUrl, // Use the OFFICIAL embed URL from API
                'reportId' => $reportId,
                'groupId' => $groupId,
                'filters' => [
                    [
                        'table' => 'ETH_SalesRepMaster',
                        'column' => 'ManagerId',
                        'value' => auth()->user()->slpCpde ?? 86
                    ]
                ]
            ];

        } catch (\Exception $e) {
            \Log::error('PowerBI Embed Configuration Error', [
                'message' => $e->getMessage(),
                'reportId' => $reportId,
                'trace' => $e->getTraceAsString()
            ]);
            return ['error' => $e->getMessage()];
        }
    }
    public function getEmbedConfigWorked()
    {
        $reportId = '309fea67-becc-4898-866e-72a7d70e4f1a';
        $groupId = '1f2c58d1-3558-480d-9c31-ce7f78a13f68';
        $tenantId = '2d64f580-311b-4579-a778-e50a164610b2';

        try {
            // Always use user token for RLS reports
            if (!Session::has('powerbi_access_token')) {
                throw new \Exception('User not authenticated. Please login first.');
            }

            $accessToken = Session::get('powerbi_access_token');
            $userInfo = Session::get('powerbi_user', []);

            \Log::info("userInfo: " . json_encode($userInfo));

            \Log::info('Generating embed token with RLS', [
                'user_email' => $userInfo['email'] ?? 'unknown',
                'reportId' => $reportId
            ]);

            // First, get report details to find the dataset ID
            $reportResponse = Http::withToken($accessToken)
                ->get("https://api.powerbi.com/v1.0/myorg/groups/{$groupId}/reports/{$reportId}");

            if ($reportResponse->failed()) {
                \Log::error('Failed to fetch report details', [
                    'error' => $reportResponse->json(),
                    'status' => $reportResponse->status()
                ]);
                throw new \Exception('Cannot access report: ' . ($reportResponse->json()['error']['message'] ?? 'Unknown error'));
            }



            $report = $reportResponse->json();
            $datasetId = $report['datasetId'] ?? null;
            $embedUrl = $report['embedUrl'] ?? null;

            if (!$datasetId || !$embedUrl) {
                throw new \Exception('Report configuration error: missing dataset or embed URL.');
            }

            \Log::info('Found dataset for RLS', ['datasetId' => $datasetId]);

            // Generate embed token with RLS (Effective Identity)
            $tokenPayload = [
                'accessLevel' => 'View',
                'allowSaveAs' => false,
                'datasets' => [
                    [
                        'id' => $datasetId,
                    ]
                ],
                'reports' => [
                    [
                        'id' => $reportId,
                    ]
                ],
                // 'identities' => [
                //     [
                //         'username' => 'admin@zenkokenya.com',//$userInfo['email'] ?? 'unknown@example.com',
                //         'roles' => ['Viewer'],
                //         'datasets' => [$datasetId]
                //     ]
                // ]
            ];

            $tokenResponse = Http::withToken($accessToken)
                ->post("https://api.powerbi.com/v1.0/myorg/groups/{$groupId}/reports/{$reportId}/GenerateToken",
                    $tokenPayload
                );

            if ($tokenResponse->failed()) {
                \Log::error('Failed to generate embed token with RLS', [
                    'error' => $tokenResponse->json(),
                    'status' => $tokenResponse->status(),
                    'payload' => $tokenPayload
                ]);
                throw new \Exception('Failed to generate embed token: ' .
                    ($tokenResponse->json()['error']['message'] ?? 'Unknown error'));
            }

            $tokenData = $tokenResponse->json();

            \Log::info('Embed token generated successfully with RLS');

            return [
                'embedToken' => $tokenData['token'],
                'embedUrl' => $embedUrl,
                'reportId' => $reportId,
                'groupId' => $groupId,
                'tenantId' => $tenantId,
                'userEmail' => $userInfo['email'] ?? 'unknown',
            ];

        } catch (\Exception $e) {
            \Log::error('PowerBI Embed Config Error', [
                'message' => $e->getMessage(),
                'reportId' => $reportId
            ]);
            return ['error' => $e->getMessage()];
        }
    }

    /**
     * Alternative: Simple embed without authentication
     */
    public function getSimpleEmbedConfig()
    {
        $reportId = '309fea67-becc-4898-866e-72a7d70e4f1a';
        $tenantId = '2d64f580-311b-4579-a778-e50a164610b2';

        return [
            'embedUrl' => "https://app.powerbi.com/reportEmbed?reportId={$reportId}&ctid={$tenantId}&autoAuth=true",
            'reportId' => $reportId,
            'tenantId' => $tenantId,
            'requiresAuth' => false,
        ];
    }

    /**
     * Check if user is authenticated
     */
    public function isAuthenticated()
    {
        // return Session::has('powerbi_access_token');
        $hasToken = !empty(session('powerbi_access_token'));
        $tokenExpired = false;

        // Check if token is expired
        if (session('powerbi_token_expires')) {
            $tokenExpired = now()->greaterThan(session('powerbi_token_expires'));
        }

        \Log::info('Power BI Auth Check', [
            'has_token' => $hasToken,
            'token_expired' => $tokenExpired,
            'expires_at' => session('powerbi_token_expires'),
            'user_email' => session('powerbi_user')['email'] ?? 'none'
        ]);

        return $hasToken && !$tokenExpired;
    }


    /**
     * Logout
     */
    public function logout()
    {
        Session::forget([
            'powerbi_access_token',
            'powerbi_refresh_token',
            'powerbi_token_expires',
            'powerbi_user'
        ]);
    }


    /**
     * Get embed configuration with RLS support - FIXED VERSION
     */
    public function getEmbedConfigOLD1()
    {
        $reportId = '309fea67-becc-4898-866e-72a7d70e4f1a';
        $groupId = '1f2c58d1-3558-480d-9c31-ce7f78a13f68';

        try {
            // Check if user has Power BI authentication
            if (!$this->isAuthenticated()) {
                throw new \Exception('User not authenticated with Power BI. Please login first.');
            }

            $accessToken = session('powerbi_access_token');
            $userInfo = session('powerbi_user', []);

            \Log::info('Generating embed token', [
                'user_email' => $userInfo['email'] ?? 'unknown',
                'has_token' => !empty($accessToken)
            ]);

            // 1. First get the report details
            $reportUrl = "https://api.powerbi.com/v1.0/myorg/groups/{$groupId}/reports/{$reportId}";

            $reportResponse = Http::withHeaders([
                'Authorization' => 'Bearer ' . $accessToken,
                'Content-Type' => 'application/json'
            ])->get($reportUrl);

            if ($reportResponse->failed()) {
                \Log::error('Failed to get report details', [
                    'status' => $reportResponse->status(),
                    'response' => $reportResponse->body()
                ]);
                throw new \Exception('Cannot access report. Status: ' . $reportResponse->status());
            }

            $reportData = $reportResponse->json();
            $datasetId = $reportData['datasetId'] ?? null;
            $embedUrl = $reportData['embedUrl'] ?? null;

            if (!$datasetId) {
                throw new \Exception('Could not find dataset ID for this report.');
            }

            \Log::info('Report details fetched', [
                'report_name' => $reportData['name'] ?? 'Unknown',
                'dataset_id' => $datasetId,
                'embed_url' => $embedUrl
            ]);

            // 2. Generate embed token with RLS
            $tokenUrl = "https://api.powerbi.com/v1.0/myorg/GenerateToken";

            $tokenPayload = [
                'datasets' => [
                    ['id' => $datasetId]
                ],
                'reports' => [
                    ['id' => $reportId]
                ],
                'targetWorkspaces' => [
                    ['id' => $groupId]
                ]
            ];

            // Add RLS identity if user email is available
            if (isset($userInfo['email']) && $userInfo['email'] !== 'unknown@example.com') {
                $tokenPayload['identities'] = [
                    [
                        'username' => $userInfo['email'],
                        'roles' => ['Viewer'],
                        'datasets' => [$datasetId]
                    ]
                ];
                \Log::info('Adding RLS identity', ['email' => $userInfo['email']]);
            }

            $tokenResponse = Http::withHeaders([
                'Authorization' => 'Bearer ' . $accessToken,
                'Content-Type' => 'application/json'
            ])->post($tokenUrl, $tokenPayload);

            if ($tokenResponse->failed()) {
                \Log::error('Embed token generation failed', [
                    'status' => $tokenResponse->status(),
                    'response' => $tokenResponse->body(),
                    'payload' => $tokenPayload
                ]);
                throw new \Exception('Failed to generate embed token. Status: ' . $tokenResponse->status());
            }

            $tokenData = $tokenResponse->json();

            \Log::info('Embed token generated successfully', [
                'token_length' => strlen($tokenData['token'] ?? ''),
                'has_token' => !empty($tokenData['token'])
            ]);

            return [
                'embedToken' => $tokenData['token'],
                'embedUrl' => $embedUrl,
                'reportId' => $reportId,
                'userEmail' => $userInfo['email'] ?? 'unknown@example.com'
            ];

        } catch (\Exception $e) {
            \Log::error('PowerBI Embed Config Error', [
                'message' => $e->getMessage(),
                'report_id' => $reportId,
                'workspace_id' => $groupId
            ]);

            // Clear invalid session
            $this->logout();

            return ['error' => $e->getMessage()];
        }
    }
}
