@extends('layouts.app')

@section('content')
<div class="container py-5 text-center">
    <h2 class="text-danger mb-3">⚠️ Power BI Error</h2>
    <p>{{ $message ?? 'Something went wrong while loading the report.' }}</p>

    <a href="{{ route('powerbi.connect') }}" class="btn btn-primary mt-3">
        Reconnect Power BI
    </a>
</div>
@endsection
