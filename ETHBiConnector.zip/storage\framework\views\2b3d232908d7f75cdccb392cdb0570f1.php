<?php $__env->startSection('content'); ?>
<div class="container py-5 text-center">
    <h2 class="text-danger mb-3">⚠️ Power BI Error</h2>
    <p><?php echo e($message ?? 'Something went wrong while loading the report.'); ?></p>

    <a href="<?php echo e(route('powerbi.connect')); ?>" class="btn btn-primary mt-3">
        Reconnect Power BI
    </a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Development\Karavel\ETHBIAuthenticator\resources\views\reports\error.blade.php ENDPATH**/ ?>