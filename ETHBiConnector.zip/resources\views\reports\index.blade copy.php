<!DOCTYPE html>
<html>
<head>
    <title>Power BI Report</title>
    <script src="https://cdn.jsdelivr.net/npm/powerbi-client@2.19.1/dist/powerbi.min.js"></script>
    <style>
        /* Your existing CSS remains the same */
        .alert-danger {
            color: #721c24;
            background-color: #f8d7da;
            border: 1px solid #f5c6cb;
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 4px;
        }
        .alert-warning {
            color: #856404;
            background-color: #fff3cd;
            border: 1px solid #ffeaa7;
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 4px;
        }
        .debug-info {
            background: #f8f9fa;
            padding: 10px;
            border-radius: 4px;
            font-family: monospace;
            font-size: 12px;
            margin: 10px 0;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>Power BI Report</h1>
        <p>User: {{ $userEmail ?? 'Unknown' }}</p>
        <a href="{{ route('powerbi.logout') }}" class="btn">Logout</a>
        <a href="{{ route('reports.simple') }}" class="btn" style="background-color: #28a745;">Simple Embed</a>
    </div>

    @if(session('success'))
        <div class="alert alert-success">
            {{ session('success') }}
        </div>
    @endif

    @if(session('error'))
        <div class="alert alert-danger">
            {{ session('error') }}
        </div>
    @endif

    <div id="loading">
        <div>Loading Power BI Report...</div>
        <div class="debug-info" id="debugInfo"></div>
    </div>
    <div id="reportContainer" style="display:none;"></div>

    <script>
        const embedToken = "{{ $embedToken }}";
        const embedUrl = "{{ $embedUrl }}";
        const reportId = "{{ $reportId }}";
        const userEmail = "{{ $userEmail ?? 'Unknown' }}";

        // Enhanced debugging
        console.log('🔧 Power BI Embed Configuration:', {
            hasToken: !!embedToken,
            tokenLength: embedToken?.length,
            hasEmbedUrl: !!embedUrl,
            hasReportId: !!reportId,
            userEmail: userEmail,
            embedUrl: embedUrl,
            reportId: reportId
        });

        function showDebugInfo(message) {
            document.getElementById('debugInfo').innerHTML = message;
        }

        function showError(message, details = '') {
            console.error('❌ Power BI Error:', message, details);
            document.getElementById('loading').innerHTML =
                '<div class="alert alert-danger">' +
                '<strong>Error Loading Report:</strong> ' + message +
                (details ? '<div class="debug-info">' + details + '</div>' : '') +
                '<br><small>Please try refreshing the page or contact support.</small>' +
                '</div>';
        }

        // Validate parameters
        if (!embedToken || embedToken.length < 100) {
            showError('Invalid embed token. Token is missing or too short.');
            throw new Error('Invalid embed token');
        }

        if (!embedUrl || !embedUrl.includes('powerbi.com')) {
            showError('Invalid embed URL.');
            throw new Error('Invalid embed URL');
        }

        if (!reportId) {
            showError('Report ID is missing.');
            throw new Error('Missing report ID');
        }

        document.addEventListener('DOMContentLoaded', function() {
            showDebugInfo('Initializing Power BI embed...');

            try {
                const models = window['powerbi-client'].models;

                showDebugInfo('Creating embed configuration...');

                const embedConfig = {
                    type: 'report',
                    tokenType: models.TokenType.Embed,
                    accessToken: embedToken,
                    embedUrl: embedUrl,
                    id: reportId,
                    permissions: models.Permissions.Read,
                    settings: {
                        navContentPaneEnabled: false,
                        panes: {
                            filters: {
                                expanded: false,
                                visible: true
                            },
                            pageNavigation: {
                                visible: true
                            }
                        },
                        background: models.BackgroundType.Transparent,
                        filterPaneEnabled: false,
                        layoutType: models.LayoutType.Custom
                    }
                };

                const reportContainer = document.getElementById('reportContainer');
                showDebugInfo('Embedding report...');

                const powerbiReport = powerbi.embed(reportContainer, embedConfig);

                // Event handlers with detailed logging
                powerbiReport.on('loaded', function() {
                    console.log('✅ Power BI Report loaded successfully');
                    showDebugInfo('Report loaded successfully!');
                    document.getElementById('loading').style.display = 'none';
                    reportContainer.style.display = 'block';
                });

                powerbiReport.on('error', function(event) {
                    console.error('❌ Power BI Embed Error Details:', event.detail);

                    let errorMessage = 'Failed to load report. ';
                    const detail = event.detail;

                    if (detail?.message?.includes('token')) {
                        errorMessage += 'Authentication token issue. ';
                        if (detail.message.includes('expired')) {
                            errorMessage += 'Token may have expired.';
                        } else {
                            errorMessage += 'Token may be invalid.';
                        }
                    } else if (detail?.message?.includes('access')) {
                        errorMessage += 'Access denied. Check user permissions.';
                    } else if (detail?.message?.includes('MSOLAP')) {
                        errorMessage += 'Data source connection failed.';
                    } else {
                        errorMessage += detail?.message || 'Unknown error occurred';
                    }

                    showError(errorMessage, JSON.stringify(detail, null, 2));
                });

                powerbiReport.on('rendered', function() {
                    console.log('✅ Power BI Report rendered successfully');
                    showDebugInfo('Report rendered completely');
                });

                powerbiReport.on('saved', function(event) {
                    console.log('Report saved:', event.detail);
                });

                // Timeout fallback
                setTimeout(function() {
                    if (document.getElementById('loading').style.display !== 'none') {
                        showError('Report loading timeout', 'Report took too long to load. Please check your connection and try again.');
                    }
                }, 30000); // 30 second timeout

            } catch (error) {
                console.error('❌ Embedding Initialization Error:', error);
                showError('Error initializing Power BI: ' + error.message, error.stack);
            }
        });

        // Add retry functionality
        function retryLoad() {
            document.getElementById('loading').innerHTML = 'Retrying...';
            document.getElementById('loading').style.display = 'block';
            document.getElementById('reportContainer').style.display = 'none';
            setTimeout(() => window.location.reload(), 1000);
        }
    </script>
</body>
</html>
