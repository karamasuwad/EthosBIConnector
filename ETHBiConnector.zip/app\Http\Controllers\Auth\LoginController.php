<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use App\Models\User;
use App\Models\BiLink;
use Illuminate\Validation\Rules;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class LoginController extends Controller
{
    /**
     * Show the login form.
     *
     * @return \Illuminate\View\View
     */
    public function index()
    {
        return view('auth.login');
    }

    /**
     * Handle a login request to the application.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function login(Request $request)
    {
        // Validate the login request
        $credentials = $request->validate([
            'email' => 'required|email',
            'password' => 'required|min:6',
        ]);

        // Attempt to authenticate the user
        if (Auth::attempt($credentials, $request->boolean('remember'))) {

            $user = Auth::user();

            if (!$user->is_active) {
                Auth::logout();
                return back()->withErrors([
                    'email' => 'Your account has been deactivated. Please contact administrator.',
                ])->onlyInput('email');
            }

            // Update last login timestamp
            $user->update([
                'last_login_at' => now(),
            ]);

            // Regenerate session for security
            $request->session()->regenerate();

            //
            // If the user is a normal user, redirect to BI report
            if ($user->is_user) {

                // $this->showReport();
                // return;
                return redirect()->route('reports.show');

            }else{
                // Otherwise go to dashboard
                return redirect()->intended('/dashboard');
            }
        }

        // Authentication failed
        return back()->withErrors([
            'email' => 'The provided credentials do not match our records.',
        ])->onlyInput('email');
    }


    /**
     * Log the user out of the application.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function logout(Request $request)
    {
        Auth::logout();

        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect('/');
    }

    /**
     * Show the dashboard after login.
     *
     * @return \Illuminate\View\View
     */
    public function dashboard()
    {
         // Get users who have logged in recently (last 30 minutes)
        $connectedUsers = User::where('is_active', true)
                            // ->where('last_login_at', '>=', now()->subMinutes(1))
                            ->orderBy('last_login_at', 'desc')
                            ->get();

        // Get session data from database (if using database sessions)
        $sessions = [];
        if (config('session.driver') === 'database') {
            $sessions = \DB::table('sessions')
                         ->where('last_activity', '>=', now()->subMinutes(30)->timestamp)
                         ->whereNotNull('user_id')
                         ->orderBy('last_activity', 'desc')
                         ->get();
        }

        $biLinks = BiLink::where('is_active', true)
                        ->orderBy('created_at', 'desc')
                        ->get();
        return view('dashboard' , compact('biLinks', 'sessions' , 'connectedUsers'));
    }



    public function getAccessToken()
    {
        $tenantId = env('POWERBI_TENANT_ID');
        $clientId = env('POWERBI_CLIENT_ID');
        $clientSecret = env('POWERBI_CLIENT_SECRET');
        $resource = env('POWERBI_RESOURCE');

        $url = "https://login.microsoftonline.com/{$tenantId}/oauth2/token";
        //for production use the following line
        /*$response = Http::asForm()->post($url, [
            'grant_type' => 'client_credentials',
            'client_id' => $clientId,
            'client_secret' => $clientSecret,
            'resource' => $resource,
        ]);*/
        $response = Http::withoutVerifying()
            ->asForm()
            ->post($url, [
                'grant_type' => 'client_credentials',
                'client_id' => $clientId,
                'client_secret' => $clientSecret,
                'resource' => $resource,
            ]);


        return $response->json('access_token');
    }
    public function getEmbedToken($reportId, $groupId)
    {
        // Step 1: Get Access Token
        $accessToken = $this->getAccessToken();

        // Step 2: Retrieve Report Details (to get datasetId)
        $reportDetails = Http::withoutVerifying()
            ->withToken($accessToken)
            ->get("https://api.powerbi.com/v1.0/myorg/groups/{$groupId}/reports/{$reportId}")
            ->json();

        if (!isset($reportDetails['datasetId'])) {
            Log::error("Failed to get datasetId for report: {$reportId}");
            return response()->json(['error' => 'Dataset ID not found for report'], 500);
        }

        $datasetId = $reportDetails['datasetId'];
        Log::info("Power BI datasetId for report {$reportId}: {$datasetId}");

        // Step 3: Build the user identity for Row-Level Security (RLS)
        $loggedInEmail =  'admin@zenkokenya.com';

        $payload = [
            'accessLevel' => 'View',
            'identities' => [
                [
                    'username' => $loggedInEmail,              // dynamic email from logged-in user
                    'roles' => ['Logged In User'],             // RLS role in Power BI
                    'datasets' => [$datasetId],                // must match report's dataset ID
                ],
            ],
        ];

        Log::info("Generating embed token with identity: " . json_encode($payload));

        // Step 4: Generate Embed Token
        $response = Http::withoutVerifying()
            ->withToken($accessToken)
            ->post("https://api.powerbi.com/v1.0/myorg/groups/{$groupId}/reports/{$reportId}/GenerateToken", $payload);

        $data = $response->json();

        if (isset($data['error'])) {
            Log::error("Power BI token generation error: " . json_encode($data));
            return response()->json(['error' => 'Failed to generate embed token', 'details' => $data], 500);
        }

        Log::info("Power BI embed token generated successfully.");

        return $data;
    }

    public function showReportOLD()
    {
        $reportId = '59c31a4e-015b-4466-8cd3-cc85b38aba21';
        // $groupId = 'f2c58d1-3558-480d-9c31-ce7f78a13f68';
        $groupId = '1f2c58d1-3558-480d-9c31-ce7f78a13f68';

        $tokenData = $this->getEmbedToken($reportId, $groupId);
        $embedToken = $tokenData['token'];
        $embedUrl = "https://app.powerbi.com/reportEmbed?reportId={$reportId}&groupId={$groupId}&config=someConfig";

        return view('reports.index', compact('embedUrl', 'embedToken'));
    }


    public function showReport2()
    {
        $accessToken = session('powerbi_access_token');
        Log::error("message " . json_encode($accessToken));

        if (!$accessToken) {
            Log::error("NO message " . json_encode($accessToken));
            return redirect()->route('powerbi.login')->with('error', 'Please sign in to Power BI first.');
        }

        $groupId = '1f2c58d1-3558-480d-9c31-ce7f78a13f68';
        $reportId = '59c31a4e-015b-4466-8cd3-cc85b38aba21';

        // Step 1: Get the report details to extract datasetId
        $reportDetails = Http::withToken($accessToken)
            ->get("https://api.powerbi.com/v1.0/myorg/groups/{$groupId}/reports/{$reportId}")
            ->json();


        Log::error("message reportDetails" . json_encode($reportDetails));

        if (!isset($reportDetails['datasetId'])) {
            Log::error("NO message reportDetails" . json_encode($reportDetails));
            return back()->with('error', 'Unable to retrieve report details or dataset ID.');
        }

        $datasetId = $reportDetails['datasetId'];
        Log::error("message datasetId" . json_encode($datasetId));

        // Step 2: Generate embed token for the logged-in user
        $embedResponse = Http::withToken($accessToken)
            ->post("https://api.powerbi.com/v1.0/myorg/groups/{$groupId}/reports/{$reportId}/GenerateToken", [
                'accessLevel' => 'View',
                // Optionally include identities if using Row-Level Security
                // 'identities' => [
                //     [
                //         'username' => auth()->user()->email ?? 'admin@zenkokenya.com',
                //         'roles' => ['Logged In User'],
                //         'datasets' => [$datasetId],
                //     ],
                // ],
            ])
            ->json();

        Log::error("message embedResponse" . json_encode($embedResponse));

        if (!isset($embedResponse['token'])) {
            Log::error("NO message embedResponse" . json_encode($embedResponse));
            return back()->with('error', 'Failed to generate embed token.');
        }

        $embedToken = $embedResponse['token'];
        $embedUrl = $reportDetails['embedUrl'];

        Log::error("message embedToken" . json_encode($embedToken));
        Log::error("message embedUrl" . json_encode($embedUrl));

        return view('reports.index', compact('embedUrl', 'embedToken'));
    }


    public function showReport()
    {

        $groupId = '1f2c58d1-3558-480d-9c31-ce7f78a13f68';
        $reportId = '59c31a4e-015b-4466-8cd3-cc85b38aba21';

        $tokenResponse = $this->getEmbedTokenNew($reportId, $groupId);

        $embedUrlResponse = Http::withoutVerifying()
            ->withToken(session('powerbi_access_token'))
            ->get("https://api.powerbi.com/v1.0/myorg/groups/{$groupId}/reports/{$reportId}")
            ->json();

            // dd($tokenResponse);
            // dd($embedUrlResponse);

        return view('reports.index', [
            'embedUrl' => $tokenResponse['embedUrl'],
            'embedToken' => $tokenResponse['embedToken'],
            'reportId' => $tokenResponse['reportId'],
        ]);


        // return view('reports.index', [
        //     'embedUrl' => $embedUrlResponse['embedUrl'],
        //     'embedToken' => $tokenResponse['token'],
        //     'reportId' => $reportId,
        // ]);
    }


    public function open_bi_report(User $user)
    {
        $biLink = BiLink::find($user->bi_link_id);

        if (!$biLink) {
            return redirect()->back()->with('error', 'BI Link not found for this user.');
        }

        return redirect($biLink->link);
    }




    // Step 1: Redirect to Microsoft login
    public function redirectToPowerBI()
    {
        $query = http_build_query([
            'client_id' => env('POWERBI_CLIENT_ID'),
            'response_type' => 'code',
            'redirect_uri' => env('POWERBI_REDIRECT_URI'), //route('powerbi.callback'),
            'response_mode' => 'query',
            'scope' => 'https://analysis.windows.net/powerbi/api/.default offline_access openid profile email',
            'state' => csrf_token(),
            'prompt' => 'select_account',
        ]);

        return redirect('https://login.microsoftonline.com/' . env('POWERBI_TENANT_ID') . '/oauth2/v2.0/authorize?' . $query);
    }

    // Step 2: Exchange code for access token
    public function handlePowerBICallback(Request $request)
    {
        $code = $request->get('code');

        $refreshToken = session('powerbi_refresh_token');
        $response = Http::asForm()->post(
            "https://login.microsoftonline.com/" . env('POWERBI_TENANT_ID') . "/oauth2/v2.0/token",
            [
                'grant_type' => 'authorization_code',
                'client_id' => env('POWERBI_CLIENT_ID'),
                'client_secret' => env('POWERBI_CLIENT_SECRET'),
                'redirect_uri' => env('POWERBI_REDIRECT_URI'), //route('powerbi.callback'),
                'code' => $code,
            ]
        );

        $data = $response->json();

        // Save tokens in session or database
        session([
            'powerbi_access_token' => $data['access_token'],
            'powerbi_refresh_token' => $data['refresh_token'],
        ]);

        return redirect()->route('reports.show')->with('success', 'Power BI connected successfully!');
    }


    public function getEmbedTokenNew($reportId, $groupId)
    {
        $accessToken = session('powerbi_access_token');

        // 1️⃣  Get report details
        $report = Http::withoutVerifying()
            ->withToken($accessToken)
            ->get("https://api.powerbi.com/v1.0/myorg/groups/{$groupId}/reports/{$reportId}")
            ->json();

        $datasetId = $report['datasetId'] ?? null;
        $embedUrl  = $report['embedUrl'] ?? null;

        if (!$datasetId || !$embedUrl) {
            return ['error' => 'Missing datasetId or embedUrl', 'data' => $report];
        }

        // 2️⃣  Generate an embed token
        $token = Http::withoutVerifying()
            ->withToken($accessToken)
            ->post("https://api.powerbi.com/v1.0/myorg/groups/{$groupId}/reports/{$reportId}/GenerateToken", [
                'accessLevel' => 'View',
                'datasets'    => [$datasetId],
            ])
            ->json();

        return [
            'embedToken' => $token['token'] ?? null,
            'embedUrl'   => $embedUrl,
            'reportId'   => $reportId,
        ];
    }



    public function getEmbedTokenNew2($reportId, $groupId)
    {
        $accessToken = session('powerbi_access_token');
        // Get report details to extract dataset
        $reportDetails = Http::withToken($accessToken)
            ->get("https://api.powerbi.com/v1.0/myorg/groups/{$groupId}/reports/{$reportId}")
            ->json();

        $datasetId = $reportDetails['datasetId'] ?? null;

        if (!$datasetId) {
            return ['error' => 'Dataset ID not found'];
        }

        // Generate embed token
        $response = Http::withToken($accessToken)
            ->post("https://api.powerbi.com/v1.0/myorg/groups/{$groupId}/reports/{$reportId}/GenerateToken", [
                'accessLevel' => 'View',
                'identities' => [
                    [
                        'username' => 'admin@zenkokenya.com',
                        'roles' => ['Logged In User'],
                        'datasets' => [$datasetId],
                    ],
                ],
            ]);

        return $response->json();
    }




}
